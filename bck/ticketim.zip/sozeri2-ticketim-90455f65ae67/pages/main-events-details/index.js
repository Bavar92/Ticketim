(function () {
    window.addEventListener("load", function () {
        var eventOptions = document.getElementsByClassName('event-option')
        var ticketPackage = document.getElementById('ticketPackage')
        var mobileEventOptions = document.getElementsByClassName('event-option-expander')
        var mobileYesButton = document.getElementsByClassName('mobile-yes')
        var body = document.getElementsByTagName('body')[0]


        for (var i = 0; i < eventOptions.length; i++) {

            eventOptions[i].addEventListener('click', function (e) {

                if (this.children[1].children[1].src.indexOf('assets/blue-left-arrow.svg') !== -1) {
                    ticketPackage.style.display = 'none'
                    this.style.border = '1px solid #333333'
                    this.children[0].style.fontWeight = 'normal'
                    this.children[0].style.color = '#333333'
                    this.children[1].children[1].src = 'assets/black-left-arrow.svg'
                } else {
                    // for (var j = 0; j < eventOptions.length; j++) {
                    //     eventOptions[j].style.border = '1px solid #333333'
                    //     eventOptions[j].children[0].style.fontWeight = 'normal'
                    //     eventOptions[j].children[0].style.color = '#333333'
                    //     eventOptions[j].children[1].children[1].src = 'assets/black-left-arrow.svg'
                    // }

                    ticketPackage.style.display = 'block'
                    this.style.border = '1px solid #00aeef'
                    this.children[0].style.fontWeight = 'bold'
                    this.children[0].style.color = '#00aeef'
                    this.children[1].children[1].src = 'assets/blue-left-arrow.svg'

                }
            }, false)

        }


        new Glider(document.querySelector('.images-glider'), {
            slidesToShow: 1,
            slidesToScroll: 1,
            dots: '.dots',
            scrollLock: true
        })

        for (var i = 0; i < mobileEventOptions.length; i++) {
            var element = mobileEventOptions[i];

            element.addEventListener('click', function (e) {
                if (this.style.maxHeight === '280px') {
                    this.style.maxHeight = '70px'
                    this.style.marginBottom = 'unset'
                    this.children[0].style.border = '2px solid #333333'
                    this.children[0].children[0].style.color = '#333333'
                    this.children[0].children[0].style.fontWeight = 'normal'
                } else {
                    this.style.maxHeight = '280px'
                    this.style.marginBottom = '20px'
                    this.children[0].style.border = '2px solid #00aeef'
                    this.children[0].children[0].style.color = '#00aeef'
                    this.children[0].children[0].style.fontWeight = 'bold'
                }
            })
        }

        for (let i = 0; i < mobileYesButton.length; i++) {
            var element = mobileYesButton[i]

            element.addEventListener('click', function (e) {
                document.getElementById('popupForm').style.display = 'block'
                body.style.overflow = 'hidden';
            })

        }

        document.getElementById('popupForm').children[0]
            .addEventListener('click', function (e) {
                e.stopPropagation();
            });

        document.getElementById('popupForm').addEventListener('click', function (e) {
            e.target.style.display = 'none'
        });

        // edit before this line
    })


})();