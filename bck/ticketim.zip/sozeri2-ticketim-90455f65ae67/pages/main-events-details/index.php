<?php
$javascriptLoad = [
    'pages/main-events-details/index.js',
];

$cssLoad = [
    'public/stylesheets/pages/main-events-details.css',
]
?>

<?php
function build_options($options, $sport, $classname)
{

    if ($sport) {
        // move this to the sport ticket page
        foreach ($options as $key => $value) {
            echo '<div class="option ' . $classname . '">';
            echo '<div class="option-details">';
            echo '<h1 class="option-title">אמסטרדם</h1>';
            echo '<p class="option-description">אמסטרדם אמסטרדם</p>';
            echo '</div>';
            echo '<div class="option-price-container">';
            echo '<div class="price-container">';
            echo '<p class="price">425</p>';
            echo '<p class="currency">€</p>';
            echo '</div>';
            echo '<p class="price-caption">מחיר בסיס</p>';
            echo '</div>';
            echo '<img src="assets/black-left-arrow.svg" class="sport-option-arrow" alt="">';
            echo '</div>';
        }

        return 1;
    }

    foreach ($options as $key => $value) {
        echo '<div class="option ' . $classname . '">';
        echo '<h1 class="option-title">אמסטרדם</h1>';
        echo '<div class="option-date-container">';
        echo '<p class="option-date">7.03.2019</p>';
        echo '<img src="assets/black-left-arrow.svg" class="option-arrow" alt="">';
        echo '</div>';
        echo '</div>';
    }
}

function event_images_slider($images)
{
    foreach ($images as $key => $value) {
        echo '<img src="assets/placeholder-image.jpg" class="image-slide" alt="">';
    }
}

function mobile_event_options($events)
{
    foreach ($events as $key => $value) {
        echo '
            <div class="event-option-expander">
                <div class="mobile-event-option">
                    <h1 class="event-option-title">אמסטרדם</h1>
                    <p class="event-date">7.03.2019</p>
                </div>
                <div class="mobile-event-option">
                    <h1 class="ticket-package-option-title">כרטיסים בלבד</h1>
                    <div class="price-container">
                        <p class="price-caption">החל מ-</p>
                        <p class="price">156 €</p>
                    </div>
                </div>
                <div class="mobile-event-option">
                    <h1 class="ticket-package-option-title">חבילת בייסיק</h1>
                    <div class="price-container">
                        <p class="price-caption">החל מ-</p>
                        <p class="price">156 €</p>
                    </div>
                </div>
                <div class="mobile-event-option">
                    <h1 class="ticket-package-option-title">חבילת Best Value</h1>
                    <div class="price-container">
                        <p class="price-caption">החל מ-</p>
                        <p class="price">156 €</p>
                    </div>
                </div>
            </div>
            ';
    }
}

function mobile_other_event_options($events)
{
    foreach ($events as $key => $value) {
        echo '
            <div class="event-option-expander">
                <div class="mobile-event-option">
                    <h1 class="event-option-title">אמסטרדם</h1>
                    <p class="event-date">7.03.2019</p>
                </div>
                <div class="package-question">
                    <img src="assets/placeholder-image.jpg" class="event-image" alt="">
                    <div class="question-container">
                        <h1 class="question">רוצים לראות את
                            אן מרי בפריז?</h1>
                        <div class="answer-buttons">
                            <button class="yes mobile-yes">כן</button>
                            <button class="no">לא</button>
                        </div>
                    </div>
                </div>
            </div>
        ';
    }
}


?>

<?php require('../../partials/header/header.php') ?>

<div class="desktop">
    <div class="event-top">
        <!-- this first right-column is  -->
        <div class="right-column">
            <h1 class="event-name">אן מארי</h1>
            <p class="bold-event-description">היא השתלטה על כל פלייליסט אפשרי עם השיר "Rockabye" בשנה שעברה וכעת מוכיחה לנו אן מארי שהיא הרבה יותר מאישה של להיט אחד, עם אינספור להיטים חדשים שמאיימים להשתלט לנו על הפלייליסט.</p>
            <p class="event-description">היא בת 26 מבריטניה הקרירה שהצליחה בשנתיים להיות בין השמות הכי לוהטים של עולם הפופ. למרות שהתפרסמה אן מארי בזכות שיתוף הפעולה שלה עם קלין בנדיט ושון פול ב"Rockabye" היא מוכיחה לכולנו שהיא לגמרי עומדת בזכות עצמה ונמצאת במגמת עלייה משמעותית בזמן האחרון. </p>
        </div>

        <!-- move this to the sport ticker page -->
        <!-- this right column is meant for sports events mainly -->
        <!-- <div class="right-column">
            <h1 class="event-name">כל האירועים ליגת האלופות </h1>
            <div class="event-info-container">
                <img src="assets/info-blue.svg" class="info-icon" alt="">
                <p class="event-info"> הוא פשוט טקסט גולמי של תעשיית ההדפסה</p>
            </div>
            <div class="event-date-container">
                <img src="assets/calendar-blue.svg" class="date-icon" alt="">
                <p class="event-date"> מועד של משחק כסופי מועד של משחק כסופי</p>
            </div>
            <div class="important-notes-container">
                <h1 class="important-notes-container-title">חשוב לדעת!</h1>
                <div class="important-note">
                    <h1 class="important-note-title">ישיבה בקבוצות:</h1>
                    <p class="important-note-description">נוכל להבטיח ישיבה בקבוצות של 2 (זוגות) אך במקרים רבים נוכל
                        להתחייב לקבוצות של 3 ומעלה בתיאום מראש עם מחלקת ההזמנות.</p>
                </div>
            </div>
        </div> -->
        <div class="left-column">
            <div class="image-gallery">
                <div class="main-image-container">
                    <img src="assets/placeholder-image.jpg" class="main-image" alt="">
                </div>
                <div class="minor-images-container">
                    <img src="assets/placeholder-image.jpg" class="minor-image" alt="">
                    <img src="assets/placeholder-image.jpg" class="minor-image" alt="">
                    <img src="assets/placeholder-image.jpg" class="minor-image" alt="">
                </div>
            </div>
        </div>
    </div>

    <div class="event-middle">
        <div class="event-middle-header">
            <h1 class="event-middle-title">משחקים חמים של הליגה</h1>
            <!-- this icon should not show in the sports page -->
            <img src="assets/fire-blue.svg" class="event-middle-hot-icon" alt="">
        </div>
        <div class="event-options-container">
            <div class="options-right">
                <?php build_options([1, 2, 3], false, 'event-options') ?>
            </div>
            <div class="options-left" id="ticketPackage">
                <div class="option">
                    <h1 class="option-title">כרטיסים בלבד</h1>
                    <div class="option-price-container">
                        <p class="price-caption">החל מ-</p>
                        <p class="price">€ 586</p>
                    </div>
                </div>
                <div class="option">
                    <h1 class="option-title">חבילת בייסיק</h1>
                    <div class="option-price-container">
                        <p class="price-caption">החל מ-</p>
                        <p class="price">€ 586</p>
                    </div>
                </div>
                <div class="option">
                    <h1 class="option-title">חבילת Best Value</h1>
                    <div class="option-price-container">
                        <p class="price-caption">החל מ-</p>
                        <p class="price">€ 586</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="event-bottom">
        <h1 class="event-bottom-title">כל האירועים של אן מארי</h1>
        <div class="event-options-container">
            <div class="options-right">
                <?php build_options([1, 2, 3], false, 'other-event-options') ?>
            </div>
            <div class="options-left" id="ticketPackage">
                <div class="package-question">
                    <img src="assets/placeholder-image.jpg" class="event-image" alt="">
                    <div class="question-container">
                        <h1 class="question">רוצים לראות את
                            אן מרי בפריז?</h1>
                        <div class="answer-buttons">
                            <button class="yes">כן</button>
                            <button class="no">לא</button>
                        </div>
                    </div>
                </div>
                <form class="short-contact-form">
                    <div class="top-form">
                        <img src="assets/placeholder-image.jpg" class="event-image" alt="">
                        <p class="form-description">מלאו את הטופס ואחד מנציגנו ייצור עמכם קשר עם הצעה נפלאה לאירוע שלכם!</p>
                    </div>
                    <div class="bottom-form">
                        <div class="text-input-container">
                            <select type="text" name="" class="text-input" value="" required>
                                <option value="" disabled selected></option>
                                <option value="">Some problem</option>
                            </select>
                            <span class="floating-label">נושא פניה</span>
                            <img src="assets/down_arrow.svg" class="down-arrow-icon" alt="">
                        </div>
                        <div class="text-input-container">
                            <input type="text" name="" class="text-input" value="" required>
                            <span class="floating-label">* שם פרטי</span>
                        </div>
                        <div class="text-input-container">
                            <input type="text" name="" class="text-input" value="" required>
                            <span class="floating-label">* מספר טלפון</span>
                        </div>
                        <input type="submit" class="submit" value="שלח">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="mobile">
    <div class="event-top-mobile">
        <h1 class="event-top-title">אן מארי</h1>
        <p class="event-top-caption">כולכם מוזמנים לקונצרטים
            באווירה קצת אחרת!</p>
        <div class="images-glider-wrapper">
            <div class="images-glider">
                <?php event_images_slider([1, 2, 3]) ?>
            </div>
            <div role="tablist" class="dots"></div>
        </div>
        <p class="event-description">היא בת 26 מבריטניה הקרירה שהצליחה בשנתיים להיות בין השמות הכי לוהטים של עולם הפופ. למרות שהתפרסמה אן מארי בזכות שיתוף הפעולה שלה עם קלין בנדיט ושון פול ב"Rockabye" היא מוכיחה לכולנו שהיא לגמרי עומדת בזכות עצמה ונמצאת במגמת עלייה משמעותית בזמן האחרון. </p>
    </div>
    <div class="event-middle-mobile">
        <div class="event-middle-header">
            <h1 class="event-middle-title">משחקים חמים של הליגה</h1>
            <!-- this icon should not show in the sports page -->
            <img src="assets/fire-blue.svg" class="event-middle-hot-icon" alt="">
        </div>
        <div class="mobile-event-options">
            <?php mobile_event_options([1, 2, 3, 4]) ?>
        </div>
    </div>

    <div class="event-bottom-mobile">
        <h1 class="event-bottom-title">משחקים חמים של הליגה</h1>
        <div class="mobile-event-options">
            <?php mobile_other_event_options([1, 2, 3, 4]) ?>
        </div>
        <div class="popup-form" id="popupForm">
            <form class="short-contact-form">
                <div class="top-form">
                    <img src="assets/placeholder-image.jpg" class="event-image" alt="">
                    <p class="form-description">מלאו את הטופס ואחד מנציגנו ייצור עמכם קשר עם הצעה נפלאה לאירוע שלכם!</p>
                </div>
                <div class="bottom-form">
                    <div class="text-input-container">
                        <select type="text" name="" class="text-input" value="" required>
                            <option value="" disabled selected></option>
                            <option value="">Some problem</option>
                        </select>
                        <span class="floating-label">נושא פניה</span>
                        <img src="assets/down_arrow.svg" class="down-arrow-icon" alt="">
                    </div>
                    <div class="text-input-container">
                        <input type="text" name="" class="text-input" value="" required>
                        <span class="floating-label">* שם פרטי</span>
                    </div>
                    <div class="text-input-container">
                        <input type="text" name="" class="text-input" value="" required>
                        <span class="floating-label">* מספר טלפון</span>
                    </div>
                    <input type="submit" class="submit" value="שלח">
                </div>
            </form>
        </div>
    </div>
</div>

<!-- move this to the sport ticket page -->
<!-- <div class="sport-packages-container">
        <h1 class="sport-packages-title">חבילות ספורט</h1>
        <div class="sport-packages">
            <div class="event-card">
                <div class="event-card-image-container">
                    <img class="event-card-image" src="assets/placeholder-image.jpg" alt="">
                    <div class="icon-contianer">
                        <img src="assets/blue-sport.svg" alt="" class="icon">
                    </div>
                </div>
                <div class="event-card-details-container">
                    <div class="right-column">
                        <h2 class="event-title">שם של מופע</h2>
                        <p class="event-sub-title">טיסה + 3 לילות במלון 4* + כרטיס </p>
                        <span class="event-date">מתאריך: 06/06/2019 עד 09/06/2019</span>

                    </div>
                    <div class="left-column">
                        <span class="starting-price">החל מ-</span>
                        <span class="price">586 €</span>
                    </div>
                </div>
            </div>
            <div class="event-card">
                <div class="event-card-image-container">
                    <img class="event-card-image" src="assets/placeholder-image.jpg" alt="">
                    <div class="icon-contianer">
                        <img src="assets/blue-sport.svg" alt="" class="icon">
                    </div>
                </div>
                <div class="event-card-details-container">
                    <div class="right-column">
                        <h2 class="event-title">שם של מופע</h2>
                        <p class="event-sub-title">טיסה + 3 לילות במלון 4* + כרטיס </p>
                        <span class="event-date">מתאריך: 06/06/2019 עד 09/06/2019</span>

                    </div>
                    <div class="left-column">
                        <span class="starting-price">החל מ-</span>
                        <span class="price">586 €</span>
                    </div>
                </div>
            </div>
            <div class="event-card">
                <div class="event-card-image-container">
                    <img class="event-card-image" src="assets/placeholder-image.jpg" alt="">
                    <div class="icon-contianer">
                        <img src="assets/blue-sport.svg" alt="" class="icon">
                    </div>
                </div>
                <div class="event-card-details-container">
                    <div class="right-column">
                        <h2 class="event-title">שם של מופע</h2>
                        <p class="event-sub-title">טיסה + 3 לילות במלון 4* + כרטיס </p>
                        <span class="event-date">מתאריך: 06/06/2019 עד 09/06/2019</span>
                    </div>
                    <div class="left-column">
                        <span class="starting-price">החל מ-</span>
                        <span class="price">586 €</span>
                    </div>
                </div>
            </div>
        </div>
    </div> -->


<?php require('../../partials/bottom-slider/index.php') ?>

<?php require('../../partials/footer/footer.php') ?>