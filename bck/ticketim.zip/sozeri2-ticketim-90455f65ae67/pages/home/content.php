<?php
$javascriptLoad = [
    'pages/home/index.js',
];

$cssLoad = [
    'public/stylesheets/pages/home.css',
    'assets/packages/cube.css',
]
?>

<?php require('../../partials/header/header.php') ?>


<div class="desktop">
    <div class="main-content-images">
        <div class="flip-card">
            <div class="card">
                <div class="card-front">
                    <img class="content-image" src="assets/placeholder-image.jpg" alt="">
                </div>
                <div class="card-back">
                    <h1 class="back-title">האירועים של אן מארי</h1>
                    <p class="back-caption">האירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-description">האירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-date">האירועים של אן מארי</p>
                </div>
            </div>
        </div>
        <div class="flip-card">
            <div class="card">
                <div class="card-front">
                    <img class="content-image" src="assets/placeholder-image.jpg" alt="">
                </div>
                <div class="card-back">
                    <h1 class="back-title">האירועים של אן מארי</h1>
                    <p class="back-caption">האירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-description">האירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-date">האירועים של אן מארי</p>
                </div>
            </div>
        </div>
        <div class="flip-card">
            <div class="card">
                <div class="card-front">
                    <img class="content-image" src="assets/placeholder-image.jpg" alt="">
                </div>
                <div class="card-back">
                    <h1 class="back-title">האירועים של אן מארי</h1>
                    <p class="back-caption">האירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-description">האירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-date">האירועים של אן מארי</p>
                </div>
            </div>
        </div>
        <div class="flip-card">
            <div class="card">
                <div class="card-front">
                    <img class="content-image" src="assets/placeholder-image.jpg" alt="">
                </div>
                <div class="card-back">
                    <h1 class="back-title">האירועים של אן מארי</h1>
                    <p class="back-caption">האירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-description">האירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-date">האירועים של אן מארי</p>
                </div>
            </div>
        </div>
        <div class="flip-card">
            <div class="card">
                <div class="card-front">
                    <img class="content-image" src="assets/placeholder-image.jpg" alt="">
                </div>
                <div class="card-back">
                    <h1 class="back-title">האירועים של אן מארי</h1>
                    <p class="back-caption">האירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-description">האירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-date">האירועים של אן מארי</p>
                </div>
            </div>
        </div>
        <div class="flip-card">
            <div class="card">
                <div class="card-front">
                    <img class="content-image" src="assets/placeholder-image.jpg" alt="">
                </div>
                <div class="card-back">
                    <h1 class="back-title">האירועים של אן מארי</h1>
                    <p class="back-caption">האירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-description">האירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-date">האירועים של אן מארי</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="mobile">
    <h1 class="main-content-title">תבחרו האירועים הכי פופולריים</h1>
    <p class="main-content-caption"> אנחנו כאן בשביכם!</p>
</div>


<div class="mobile">
    <div class="main-content-images-mobile">
        <div>
            <img class="content-image" src="assets/placeholder-image.jpg" alt="">
            <span class="content-title">הוא פשוט טקסט גולמי</span>
            <span class="content-caption">04/05/2019 - 12/11/2019</span>
        </div>
        <div>
            <img class="content-image" src="assets/placeholder-image.jpg" alt="">
            <span class="content-title">הוא פשוט טקסט גולמי</span>
            <span class="content-caption">04/05/2019 - 12/11/2019</span>
        </div>
        <div>
            <img class="content-image" src="assets/placeholder-image.jpg" alt="">
            <span class="content-title">הוא פשוט טקסט גולמי</span>
            <span class="content-caption">04/05/2019 - 12/11/2019</span>
        </div>
    </div>
</div>

<div class="mobile mobile-banner-container">
    <img src="assets/placeholder-image.jpg" class="mobile-banner-image" alt="">
    <span class="mobile-banner-title">הוא פשוט טקסט גולמי</span>
    <span class="mobile-banner-caption">04/05/2019 - 12/11/2019</span>
</div>
<div class="user-experience-container">
    <div class="main-cube">
        <div class="container">
            <div class="wrapper">
                <div class="cont">
                    <div class="cube">
                        <figure class="front cube-category" data-category="0">מבצעים</figure>
                        <figure class="back cube-category" data-category="1">הופעות</figure>
                        <figure class="right cube-category" data-category="2">ספורט</figure>
                        <figure class="left cube-category" data-category="3">אטרקציות</figure>
                        <figure class="top cube-category" data-category="4">פסטיבלים</figure>
                        <figure class="bottom cube-category" data-category="5">מומלצים</figure>
                    </div>
                </div>
            </div>
        </div>
        <div class="canvas flex-container">
            <div class="col-lg-4">
                <div class="bg cool"><canvas id="tenthSection_1" height="200" width="617"></canvas></div>
            </div>
            <div class="col-lg-8">
                <div class="bg awesome"><canvas id="tenthSection_2" height="200" width="1235"></canvas></div>
            </div>
        </div>
    </div>
    <h1 class="user-experience-title desktop">מה החוויה שלך?" </h1>
    <img src="assets/pointing_person.jpg" class="user-experience-image desktop" alt="">
</div>

<?php require('../../partials/bottom-slider/index.php') ?>

<?php require('../../partials/footer/footer.php') ?>