(function () {
    window.addEventListener("load", function () {

        var desktopSearchCategories = document.getElementsByClassName('search-category-select')
        var dekstopSeachSubCategories = document.getElementsByClassName('search-sub-category')

        flatpickr(document.getElementById('desktop-search-date-input'), {
            mode: 'range',
            locale: 'he',
            onChange: function (selectedDates, dateStr, instance) {
                // if he only chose 1 day
                if (selectedDates.length === 1) {
                    document.getElementById('desktop-search-date-input').textContent = new Date(selectedDates[0]).toISOString().split('T')[0]
                    // if he chose a range of days 
                } else if (selectedDates.length === 2) {
                    document.getElementById('desktop-search-date-input').textContent = new Date(selectedDates[0]).toISOString().split('T')[0] + ' - ' + new Date(selectedDates[1]).toISOString().split('T')[0]

                }
            },
        })

        for (let i = 0; i < desktopSearchCategories.length; i++) {
            var count = 0;

            for (var j = 0; j < dekstopSeachSubCategories.length; j++) {
                if (Number(dekstopSeachSubCategories[j].dataset.category) === i) {
                    count++;

                    // you should probably add an event listener here which every time is clicked
                    // it adds a key or an entry to an object
                    // just like a react state
                    // and then when someone clicks confirm to filter
                    // just send that object to the server or something ?
                    // oh you also need e.stopPropagation(); in the event listener
                    dekstopSeachSubCategories[j].addEventListener('click', function (e) {
                        e.stopPropagation()

                        if (e.path[0].children[0].src.indexOf('assets/eye-grey.svg') !== -1) {
                            e.path[0].children[0].src = 'assets/eye-blue.svg'
                            e.path[0].style.backgroundColor = '#ebebeb'
                        } else {
                            e.path[0].children[0].src = 'assets/eye-grey.svg'
                            e.path[0].style.backgroundColor = 'white'

                        }
                    })
                }

                // check which sub category is currently selected and highlight it in the menu
                // if (
                //     (params.get('sub_category') !== null && Number(params.get('sub_category'))) === j &&
                //     (params.get('category') !== null && Number(params.get('category'))) === i
                // ) {

                //     mobileSubCategories[j].style.backgroundColor = 'white'
                // }
            }

            desktopSearchCategories[i].addEventListener('click', function (e) {
                if (e.path[1].style.height.split('px')[0] > 85) {
                    e.path[1].style.height = '85px'
                    e.path[0].children[0].style.color = '#333333'
                    e.target.style.border = 'solid 1px #333333'
                    e.path[0].children[1].src = 'assets/black-left-arrow.svg'
                } else {
                    // 55px for each sub-category
                    e.path[1].style.height = count * 85 + 85 + 'px'
                    e.target.style.border = 'solid 1px #00aeef'
                    e.path[0].children[1].src = 'assets/down_arrow.svg'
                    e.path[0].children[0].style.color = '#00aeef'
                }
            }, false)
        }

        // edit before this line
    })
})();