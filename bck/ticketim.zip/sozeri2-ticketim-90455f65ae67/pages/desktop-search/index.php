<?php
$javascriptLoad = [
    'pages/desktop-search/index.js',
];

$cssLoad = [
    'public/stylesheets/pages/desktop-search.css',
];
?>

<?php
function build_search_events($events)
{

    foreach ($events as $key => $value) {
        echo '<div class="search-event-wrapper">';
        echo '<img src="assets/placeholder-image.jpg" class="search-event-image" /> ';
        echo '<div class="search-event-details-container">';
        echo '<h1 class="search-event-title">דיוויד גארט</h1>';
        echo '<div class="search-event-location-container">';
        echo '<img src="assets/location-blue.svg" class="search-event-location-icon" />';
        echo '<span class="search-event-location">שטוקהולם</span>';
        echo '</div>';
        echo '</div>';
        echo '<img src="assets/location-blue.svg" class="search-event-type-icon" />';
        echo '</div>';
    }
}

function build_search_sub_categories($sub_categories, $main_category_id)
{
    echo '<ul class="search-sub-categories-list">';

    foreach ($sub_categories as $key => $sub) {
        echo '<li class="search-sub-category" data-sub="' . $key . '" data-category="' . $main_category_id . '"><img src="assets/eye-blue.svg" class="filter-sub-category-icon" />'  . $sub . '</li>' . "\n";
    }

    echo '</ul>';
}

?>

<?php require('../../partials/header/header.php') ?>

<div class="desktop">
    <div class="search-container">
        <form class="search-form" action="">
            <h1 class="search-form-title">סנן אופן תצוגה בעמוד</h1>
            <div class="categories-checkboxes-wrapper">
                <div class="search-category">
                    <label class="checkbox-container">
                        <input type="checkbox" name="" id="searchSports" class="checkbox">
                        <span class="checkmark"></span>
                    </label>
                    <label for="searchSports" class="search-category-title">ספורט</label>
                </div>
                <div class="search-category">
                    <label class="checkbox-container">
                        <input type="checkbox" name="" id="searchConcerts" class="checkbox">
                        <span class="checkmark"></span>
                    </label>
                    <label for="searchConcerts" class="search-category-title">הופעות</label>
                </div>
                <div class="search-category">
                    <label class="checkbox-container">
                        <input type="checkbox" name="" id="searchAttractions" class="checkbox">
                        <span class="checkmark"></span>
                    </label>
                    <label for="searchAttractions" class="search-category-title">אטרקציות/ מחוזות זמר</label>
                </div>
                <div class="search-category">
                    <label class="checkbox-container">
                        <input type="checkbox" name="" id="searchFestivals" class="checkbox">
                        <span class="checkmark"></span>
                    </label>
                    <label for="searchFestivals" class="search-category-title">פסטיבלים</label>
                </div>
            </div>
            <div class="input-container">
                <div class="icon-input">
                    <input type="text" name="" class="text-input" placeholder="עיר/מדינה">
                    <img src="assets/location-blue.svg" class="icon" alt="">
                </div>
                <!-- https://flatpickr.js.org/examples/#range-calendar -->
                <div class="icon-input">
                    <div id="desktop-search-date-input" class="date-picker">תאריך</div>
                    <img src="assets/calendar-blue.svg" class="icon" alt="">
                </div>
            </div>
            <div class="search-category-container">
                <div class="search-category-select">
                    <div class="category-title-wrapper">
                        <h1 class="filter-category-title">הופעות</h1>
                        <img src="assets/black-left-arrow.svg" class="down-arrow" alt="">
                    </div>
                    <?php build_search_sub_categories(array('Sweet child', 'Sweet child'), 0) ?>
                </div>
                <div class="search-category-select">
                    <div class="category-title-wrapper">
                        <h1 class="filter-category-title">הופעות</h1>
                        <img src="assets/black-left-arrow.svg" class="down-arrow" alt="">
                    </div>
                    <?php build_search_sub_categories(array('Sweet child', 'Sweet child'), 1) ?>
                </div>
                <div class="search-category-select">
                    <div class="category-title-wrapper">
                        <h1 class="filter-category-title">הופעות</h1>
                        <img src="assets/black-left-arrow.svg" class="down-arrow" alt="">
                    </div>
                    <?php build_search_sub_categories(array('Sweet child', 'Sweet child'), 2) ?>
                </div>
                <div class="search-category-select">
                    <div class="category-title-wrapper">
                        <h1 class="filter-category-title">הופעות</h1>
                        <img src="assets/black-left-arrow.svg" class="down-arrow" alt="">
                    </div>
                    <?php build_search_sub_categories(array('Sweet child', 'Sweet child'), 3) ?>
                </div>
                <div class="search-category-select">
                    <div class="category-title-wrapper">
                        <h1 class="filter-category-title">הופעות</h1>
                        <img src="assets/black-left-arrow.svg" class="down-arrow" alt="">
                    </div>
                    <?php build_search_sub_categories(array('Sweet child', 'Sweet child'), 4) ?>
                </div>
            </div>
        </form>
        <div class="search-events-container">
            <?php build_search_events([1, 2, 3, 4, 5, 6, 7, 8, 8, 1, 2, 3, 4, 5]) ?>
        </div>
    </div>
</div>


<?php require('../../partials/bottom-slider/index.php') ?>

<?php require('../../partials/footer/footer.php') ?>