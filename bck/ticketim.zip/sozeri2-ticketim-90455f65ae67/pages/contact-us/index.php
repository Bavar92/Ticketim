<?php
$cssLoad = [
    'public/stylesheets/pages/contact-us.css',
]
?>

<?php require('../../partials/header/header.php') ?>

<div class="desktop">
    <div class="contact-us">
        <div class="right-column">
            <h1 class="right-column-title">בכל שאלה או בקשה ניתן לפנות אלינו באמצעות:</h1>
            <form action="" novalidate>

                <div class="text-input-container">
                    <select type="text" name="" class="text-input" value="" required>
                        <option value="" disabled selected></option>
                        <option value="">Some problem</option>
                    </select>
                    <span class="floating-label">נושא פניה</span>
                    <img src="assets/down_arrow.svg" class="down-arrow-icon" alt="">
                </div>
                <div class="text-input-container">
                    <input type="text" name="" class="text-input" value="" required>
                    <span class="floating-label">* שמ פרטי</span>
                </div>
                <div class="text-input-container">
                    <input type="text" name="" class="text-input" value="" required>
                    <span class="floating-label">* מספר טלפון</span>
                </div>
                <div class="text-input-container">
                    <input type="text" name="" class="text-input" value="" required>
                    <span class="floating-label">כתובת מייל</span>
                </div>
                <div class="text-input-container">
                    <input type="text" name="" class="text-input" value="" required>
                    <span class="floating-label">מכתב מקדים</span>
                </div>
                <p class="must-inputs">* שדות מילוי חובה</p>
                <div class="marketing-agreement-container">
                    <label class="checkbox-container">
                        <input type="checkbox" name="" class="checkbox" id="marketingAgreement">
                        <span class="checkmark"></span>
                    </label>
                    <label for="marketingAgreement" class="marketing-agreement-label">אני מאשר לשלוח לי חומר פרסומי</label>
                </div>
                <input type="submit" class="submit" value="שלח">
            </form>
        </div>
        <div class="left-column">
            <div class="method-container">
                <img src="assets/phone-blue.svg" class="method-icon" alt="">
                <p class="short-phone-number">3120*</p>
                <p class="phone-number">03-5663120</p>
            </div>
            <div class="method-container">
                <img src="assets/mail-icon.svg" class="method-icon" alt="">
                <p>info@ticketim.co.il</p>
            </div>
            <div class="method-container">
                <p class="other-option">כמו כן ניתן למצוא אותנו גם
                    ברשתות חברתיות וגם לשתף חברים</p>
                <img src="assets/social-media-down-arrow.svg" class="method-icon" alt="">
            </div>
        </div>
    </div>
</div>



<div class="mobile">
    <div class="mobile-contact-us">
        <h1 class="title">בכל שאלה או בקשה ניתן לפנות אלינו באמצעות:</h1>
        <div class="method-container">
            <img src="assets/phone-blue.svg" class="method-icon" alt="">
            <p class="short-phone-number">3120*</p>
            <p class="phone-number">03-5663120</p>
        </div>
        <div class="method-container">
            <img src="assets/mail-icon.svg" class="method-icon" alt="">
            <p>info@ticketim.co.il</p>
        </div>
        <form action="" novalidate>

            <div class="text-input-container">
                <select type="text" name="" class="text-input" value="" required>
                    <option value="" disabled selected></option>
                    <option value="">Some problem</option>
                </select>
                <span class="floating-label">נושא פניה</span>
                <img src="assets/down_arrow.svg" class="down-arrow-icon" alt="">
            </div>
            <div class="text-input-container">
                <input type="text" name="" class="text-input" value="" required>
                <span class="floating-label">* שמ פרטי</span>
            </div>
            <div class="text-input-container">
                <input type="text" name="" class="text-input" value="" required>
                <span class="floating-label">* מספר טלפון</span>
            </div>
            <div class="text-input-container">
                <input type="text" name="" class="text-input" value="" required>
                <span class="floating-label">כתובת מייל</span>
            </div>
            <div class="text-input-container">
                <input type="text" name="" class="text-input" value="" required>
                <span class="floating-label">מכתב מקדים</span>
            </div>
            <p class="must-inputs">* שדות מילוי חובה</p>
            <div class="marketing-agreement-container">
                <label class="checkbox-container">
                    <input type="checkbox" name="" class="checkbox" id="marketingAgreement">
                    <span class="checkmark"></span>
                </label>
                <label for="marketingAgreement" class="marketing-agreement-label">אני מאשר לשלוח לי חומר פרסומי</label>
            </div>
            <input type="submit" class="submit" value="שלח">
        </form>
        <div class="method-container">
            <p class="other-option">כמו כן ניתן למצוא אותנו גם
                ברשתות חברתיות וגם לשתף חברים</p>
            <img src="assets/social-media-down-arrow.svg" class="method-icon" alt="">
        </div>
    </div>
</div>

<?php require('../partials/footer/footer.php') ?>