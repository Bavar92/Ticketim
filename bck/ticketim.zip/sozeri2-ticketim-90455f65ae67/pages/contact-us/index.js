(function () {
    window.addEventListener("load", function () {



        // edit before this line
    })


})();