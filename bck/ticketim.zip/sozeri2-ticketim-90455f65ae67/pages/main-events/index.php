<?php
$javascriptLoad = [
    'pages/main-events/index.js',
];

$cssLoad = [
    'public/stylesheets/pages/main-events.css',
];
?>

<?php
function events($events)
{

    foreach ($events as $key => $event) {
        echo '<div class="event-card">
    <div class="event-card-image-container">
        <img class="event-card-image" src="assets/placeholder-image.jpg" alt="">
        <div class="icon-contianer">
            <img src="assets/view-icon.svg" alt="" class="icon">
        </div>
    </div>
    <div class="event-card-details-container">
        <div class="right-column">
            <h2 class="event-title">שם של מופע</h2>
            <p class="event-sub-title">טיסה + 3 לילות במלון 4* + כרטיס </p>
            <span class="event-date">מתאריך: 06/06/2019 עד 09/06/2019</span>
        </div>
    </div>
</div>';
    }
}

function build_filter_sub_categories($sub_categories, $main_category_id)
{
    echo '<ul class="mobile-sub-categories-list">';

    foreach ($sub_categories as $key => $sub) {
        echo '<li class="filter-sub-category" data-sub="' . $key . '" data-category="' . $main_category_id . '"><img src="assets/eye-blue.svg" class="filter-sub-category-icon" />'  . $sub . '</li>' . "\n";
    }

    echo '</ul>';
}
?>

<?php require('../../partials/header/header.php') ?>
<div class="desktop">
    <div class="main-content-images">
        <div class="flip-card">
            <div class="card">
                <div class="card-front">
                    <img class="content-image" src="assets/placeholder-image.jpg" alt="">
                </div>
                <div class="card-back">
                    <h1 class="back-title">האירועים של אן מארי</h1>
                    <p class="back-caption">האירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-description">האירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-date">האירועים של אן מארי</p>
                </div>
            </div>
        </div>
        <div class="flip-card">
            <div class="card">
                <div class="card-front">
                    <img class="content-image" src="assets/placeholder-image.jpg" alt="">
                </div>
                <div class="card-back">
                    <h1 class="back-title">האירועים של אן מארי</h1>
                    <p class="back-caption">האירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-description">האירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-date">האירועים של אן מארי</p>
                </div>
            </div>
        </div>
        <div class="flip-card">
            <div class="card">
                <div class="card-front">
                    <img class="content-image" src="assets/placeholder-image.jpg" alt="">
                </div>
                <div class="card-back">
                    <h1 class="back-title">האירועים של אן מארי</h1>
                    <p class="back-caption">האירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-description">האירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-date">האירועים של אן מארי</p>
                </div>
            </div>
        </div>
        <div class="flip-card">
            <div class="card">
                <div class="card-front">
                    <img class="content-image" src="assets/placeholder-image.jpg" alt="">
                </div>
                <div class="card-back">
                    <h1 class="back-title">האירועים של אן מארי</h1>
                    <p class="back-caption">האירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-description">האירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-date">האירועים של אן מארי</p>
                </div>
            </div>
        </div>
        <div class="flip-card">
            <div class="card">
                <div class="card-front">
                    <img class="content-image" src="assets/placeholder-image.jpg" alt="">
                </div>
                <div class="card-back">
                    <h1 class="back-title">האירועים של אן מארי</h1>
                    <p class="back-caption">האירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-description">האירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-date">האירועים של אן מארי</p>
                </div>
            </div>
        </div>
        <div class="flip-card">
            <div class="card">
                <div class="card-front">
                    <img class="content-image" src="assets/placeholder-image.jpg" alt="">
                </div>
                <div class="card-back">
                    <h1 class="back-title">האירועים של אן מארי</h1>
                    <p class="back-caption">האירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-description">האירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מאריהאירועים של אן מארי</p>
                    <p class="back-date">האירועים של אן מארי</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main-events">
    <div class="desktop-order">
        <?php events([1, 2, 3, 4, 5, 6, 7]) ?>
    </div>
    <div class="view-more">להציג עוד</div>
</div>

<div class="mobile">
    <div class="filter-sort-footer" id="filterSortFooter">
        <div id="filterButton" class="filter-sort-container">
            <span class="filter-sort-text" id="filterText">סנן</span>
            <img src="assets/filter-grey.svg" class="filter-sort-icon" id="filterIcon" alt="">
        </div>
        <div class="line">|</div>
        <div id="sortButton" class="filter-sort-container">
            <span class="filter-sort-text" id="sortText">מיין</span>
            <img src="assets/sort-grey.svg" class="filter-sort-icon" id="sortIcon" alt="">
        </div>
    </div>
</div>

<div class="mobile">
    <div class="sidemenu" id="filterSidemenu">
        <div class="filter-categories">
            <img src="assets/x.svg" class="close" alt="">
            <div class="category">
                <div class="category-title-wrapper">
                    <h1 class="filter-category-title">הופעות</h1>
                    <img src="assets/down_arrow.svg" class="down-arrow" alt="">
                </div>
                <?php build_filter_sub_categories(array('Sweet child', 'Sweet child'), 0) ?>
            </div>
            <div class="category">
                <div class="category-title-wrapper">
                    <h1 class="filter-category-title">הופעות</h1>
                    <img src="assets/down_arrow.svg" class="down-arrow" alt="">
                </div>
                <?php build_filter_sub_categories(array('Sweet child', 'Sweet child'), 1) ?>
            </div>
            <div class="category">
                <div class="category-title-wrapper">
                    <h1 class="filter-category-title">הופעות</h1>
                    <img src="assets/down_arrow.svg" class="down-arrow" alt="">
                </div>
                <?php build_filter_sub_categories(array('Sweet child', 'Sweet child'), 2) ?>
            </div>
            <div class="category">
                <div class="category-title-wrapper">
                    <h1 class="filter-category-title">הופעות</h1>
                    <img src="assets/down_arrow.svg" class="down-arrow" alt="">
                </div>
                <?php build_filter_sub_categories(array('Sweet child', 'Sweet child'), 3) ?>
            </div>
            <div class="category">
                <div class="category-title-wrapper">
                    <h1 class="filter-category-title">הופעות</h1>
                    <img src="assets/down_arrow.svg" class="down-arrow" alt="">
                </div>
                <?php build_filter_sub_categories(array('Sweet child', 'Sweet child'), 4) ?>
            </div>
        </div>
        <div class="filter-actions-container">
            <button class="confirm-filters">אישור</button>
            <button class="clean-filters">נקה הכל</button>
        </div>
    </div>
    <div class="sidemenu" id="sortSidemenu">
        <form class="sort-categories">
            <img src="assets/x.svg" class="close" alt="">
            <div class="input-container" id="sortInputContainer">
                <div class="icon-input">
                    <input type="text" name="" class="text-input" placeholder="עיר/מדינה">
                    <img src="assets/location-blue.svg" class="icon" alt="">
                </div>
                <!-- https://flatpickr.js.org/examples/#range-calendar -->
                <div class="icon-input">
                    <div id="sort-date-input" class="date-picker">תאריך</div>
                    <img src="assets/calendar-blue.svg" class="icon" alt="">
                </div>
            </div>
            <div class="sort-category">
                <label class="checkbox-container">
                    <input type="checkbox" name="" id="sortSport" class="checkbox">
                    <span class="checkmark"></span>
                </label>
                <label for="sortSport" class="sort-category-title">ספורט</label>
            </div>
            <div class="sort-category">
                <label class="checkbox-container">
                    <input type="checkbox" name="" id="sortConcerts" class="checkbox">
                    <span class="checkmark"></span>
                </label>
                <label for="sortConcerts" class="sort-category-title">הופעות</label>
            </div>
            <div class="sort-category">
                <label class="checkbox-container">
                    <input type="checkbox" name="" id="sortAttractions" class="checkbox">
                    <span class="checkmark"></span>
                </label>
                <label for="sortAttractions" class="sort-category-title">אטרקציות/ מחוזות זמר</label>
            </div>
            <div class="sort-category">
                <label class="checkbox-container">
                    <input type="checkbox" name="" id="sortFestivals" class="checkbox">
                    <span class="checkmark"></span>
                </label>
                <label for="sortFestivals" class="sort-category-title">פסטיבלים</label>
            </div>
        </form>
        <div class="filter-actions-container">
            <button class="confirm-filters">אישור</button>
            <button class="clean-filters">נקה הכל</button>
        </div>
    </div>
</div>

<?php require('../../partials/bottom-slider/index.php') ?>

<?php require('../../partials/footer/footer.php') ?>