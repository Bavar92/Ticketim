<?php
$javascriptLoad = [
    'pages/hot-sales/index.js',
];

$cssLoad = [
    'public/stylesheets/pages/sports-categories.css',
];
?>

<?php
function events($events)
{

    foreach ($events as $key => $event) {
        echo '<div class="event-card">
            <div class="event-card-image-container">
                <img class="event-card-image" src="assets/placeholder-image.jpg" alt="">
                <div class="icon-contianer">
                    <img src="assets/view-icon.svg" alt="" class="icon">
                </div>
            </div>
            <div class="event-card-details-container">
                <div class="right-column">
                    <h2 class="sport-category">שם של מופע</h2>
                </div>
            </div>
        </div>';
    }
}
?>

<?php require('../../partials/header/header.php') ?>
<div class="sports-categories">
    <h1 class="sports-categories-title">קטגוריות ראשיות</h1>
    <div class="desktop-order">
        <?php events([1, 2, 3, 4, 5, 6, 7, 8]) ?>
    </div>
    <div class="view-more">להציג עוד</div>
</div>

<?php require('../../partials/bottom-slider/index.php') ?>

<?php require('../../partials/footer/footer.php') ?>