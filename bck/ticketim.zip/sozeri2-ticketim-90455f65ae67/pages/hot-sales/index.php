<?php
$javascriptLoad = [
    'pages/hot-sales/index.js',
];

$cssLoad = [
    'public/stylesheets/pages/hot-sales.css',
];
?>

<?php
function events($events)
{

    foreach ($events as $key => $event) {
        echo '<div class="event-card">
            <div class="event-card-image-container">
                <img class="event-card-image" src="assets/placeholder-image.jpg" alt="">
                <div class="icon-contianer">
                    <img src="assets/view-icon.svg" alt="" class="icon">
                    <span class="view-count">120</span>
                </div>
            </div>
            <div class="event-card-details-container">
                <div class="right-column">
                    <h2 class="event-title">שם של מופע</h2>
                    <p class="event-sub-title">טיסה + 3 לילות במלון 4* + כרטיס </p>
                    <span class="event-date">מתאריך: 06/06/2019 עד 09/06/2019</span>

                </div>
                <div class="left-column">
                    <span class="starting-price">החל מ-</span>
                    <span class="price">586 €</span>
                </div>
            </div>
        </div>';
    }
}
?>

<?php require('../../partials/header/header.php') ?>
<div class="sales-override">
    <div class="desktop-sales-nav">
        <span class="sales-nav-item">כל המבצעים</span>
        <span class="line">|</span>
        <span class="sales-nav-item">הופעות</span>
        <span class="line">|</span>
        <span class="sales-nav-item">ספורט</span>
        <span class="line">|</span>
        <span class="sales-nav-item">אטרקציות ומחזות זמר</span>
        <span class="line">|</span>
        <span class="sales-nav-item">פסטיבלים</span>
    </div>
    <div class="desktop-order">
        <?php events([1, 2, 3, 4, 5, 6, 7, 8]) ?>
    </div>
    <div class="view-more">לעוד מבצעים>></div>
</div>
<!-- 
<div class="hover-cart" id="hoverCart">
    <div class="top-cart">
        <p class="price">€500.00</p>
        <div class="quantity">
            <p class="quantity-label">כמות:</p>
            <select class="quantity-amount" name="">
                <option value="">2</option>
            </select>
            <button>הוסף לסל</button>
        </div>
    </div>
</div> -->

<?php require('../../partials/bottom-slider/index.php') ?>

<?php require('../../partials/footer/footer.php') ?>