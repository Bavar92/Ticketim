To start the project in development mode run 

```bash
sass --watch theme/:public/stylesheets
```
in your CLI