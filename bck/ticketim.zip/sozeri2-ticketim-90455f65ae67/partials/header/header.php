<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <base href="/">

    <script type="application/javascript" src="assets/packages/glider.min.js"></script>
    <script type="application/javascript" src="/partials/header/index.js"></script>
    <script type="application/javascript" src="/partials/bottom-slider/index.js"></script>
    <link rel="stylesheet" href="assets/packages/glider.min.css">
    <link rel="stylesheet" href="public/stylesheets/partials/header.css">
    <link rel="stylesheet" href="public/stylesheets/partials/footer.css">
    <link rel="stylesheet" href="public/stylesheets/partials/bottom-slider.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://npmcdn.com/flatpickr/dist/l10n/he.js"></script>
    <?php
    if (isset($javascriptLoad)) {
        foreach ($javascriptLoad as $script) {
            echo '<script type="application/javascript" src="' . $script . '"></script>' . "\n";
        }
    }

    if (isset($cssLoad)) {
        foreach ($cssLoad as $src) {
            echo '<link rel="stylesheet" href="' . $src . '"></link>' . "\n";
        }
    }

    function build_sub_categories($sub_categories, $main_category_id)
    {
        echo '<ul class="left-border sub-categories-list">';
        foreach ($sub_categories as $key => $sub) {

            if ($key == 5) {
                echo '</ul>';
                echo '<ul class="sub-categories-list">';
            }

            echo '<li class="sub-category" data-sub="' . $key . '" data-category="' . $main_category_id . '">' . $sub . '</li>' . "\n";
        }
        echo '</ul>';

        if (count($sub_categories) <= 5) {
            echo '<div class="banner">&nbsp;</div>';
            echo '<div class="banner">&nbsp;</div>';
            echo '<div class="banner">&nbsp;</div>';
        } else if (count($sub_categories) <= 10) {
            echo '<div class="banner">&nbsp;</div>';
            echo '<div class="banner">&nbsp;</div>';
        } else {
            echo '<div class="banner">&nbsp;</div>';
        }
    };

    function build_mobile_sub_categories($sub_categories, $main_category_id)
    {
        echo '<ul class="mobile-sub-categories-list">';

        foreach ($sub_categories as $key => $sub) {
            echo '<li class="mobile-sub-category" data-sub="' . $key . '" data-category="' . $main_category_id . '">' . $sub . '</li>' . "\n";
        }

        echo '</ul>';
    }
    ?>

</head>

<body>
    <div class="main-header">
        <div class="top-header">
            <div class="top-header-details">
                <img src="assets/clock.svg" class="smaller-icon" alt="">
                <span>08-0-22:00 24/7</span>
            </div>
            <div class="top-header-details">
                <img src="assets/phone.svg" class="smaller-icon" alt="">
                <span>972-(0)3-5663120</span>
            </div>
            <div class="top-header-details">
                <div class="cart-container">
                    <img src="assets/cart.svg" class="icon" alt="">
                    <div class="cart">1</div>
                </div>
            </div>
        </div>
        <div class="bottom-header">
            <img class="logo" src="assets/logo.png" alt="">
            <div class="nav-item-wrapper">
                <h1 class="nav-item" data-category="0">מבצעים חמים</h1>
                <div class="expander">
                    <div class="subcategories-wrapper">
                        <?php build_sub_categories(array('מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א'), 0) ?>
                    </div>
                </div>
            </div>
            <div class="nav-item-wrapper">
                <h1 class="nav-item">הופעות</h1>
                <div class="expander">
                    <div class="subcategories-wrapper">
                        <?php build_sub_categories(array('מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א'), 1) ?>
                    </div>
                </div>
            </div>
            <div class="nav-item-wrapper">
                <h1 class="nav-item">ספורט</h1>
                <div class="expander">
                    <div class="subcategories-wrapper">
                        <?php build_sub_categories(array('מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א'), 2) ?>
                    </div>
                </div>
            </div>
            <div class="nav-item-wrapper">
                <h1 class="nav-item">אטרקציות ומחזות זמר</h1>
                <div class="expander">
                    <div class="subcategories-wrapper">
                        <?php build_sub_categories(array('מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א'), 3) ?>
                    </div>
                </div>
            </div>
            <div class="nav-item-wrapper">
                <h1 class="nav-item">פסטיבלים</h1>
                <div class="expander">
                    <div class="subcategories-wrapper">
                        <?php build_sub_categories(array('מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א', 'מאריו סאליבה עם א'), 4) ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="fixed-header" id="mobileHeader">
        <div class="mobile-main-header">
            <div class="top-header">
                <div class="form-header" style="position:absolute; transform: translateY(-1000%);" id="headerSearchForm">
                    <div class="icon-input">
                        <input type="text" name="" class="text-input" placeholder="אמן/קבוצה">
                        <img src="assets/people.svg" class="icon" alt="">
                    </div>
                    <div class="icon-input">
                        <input type="text" name="" class="text-input" placeholder="עיר/מדינה">
                        <img src="assets/location.svg" class="icon" alt="">
                    </div>
                    <!-- https://flatpickr.js.org/examples/#range-calendar -->
                    <div class=" icon-input">
                        <div id="date-input" class="date-picker">תאריך</div>
                        <img src="assets/calendar.svg" class="icon" alt="">
                    </div>
                    <div class=" icon-input">
                        <select name="" class="text-input">
                            <option value="" disabled selected>סוג האירוע </option>
                            <option value="">Option 1</option>
                            <option value="">Option 1</option>
                        </select>
                        <img src="assets/type.svg" class="icon" alt="">
                    </div>
                    <!-- 2 submit down here 1 for desktop and other for mobile -->
                    <div class="submit-container desktop">
                        <input type="submit" class="submit" value="">
                        <img src="assets/search.svg" class="submit-icon" alt="">
                    </div>
                    <div class="submit-container mobile" id="close-header-form">
                        <input type="submit" class="submit" value="">
                        <img src="assets/search.svg" class="submit-icon" alt="">
                    </div>
                </div>
                <img class="logo" src="assets/logo.png" id="mobileLogo" alt="">
                <span id="headerSearchButton" class="header-search">חיפוש מתקדם<img src="assets/search-black.svg" style="width: 20px;margin-right: 10px;" /></span>
                <div class="actions">
                    <div class="cart-container">
                        <img src="assets/cart.svg" class="icon" alt="">
                        <div class="cart">2</div>
                    </div>
                    <img src="assets/cripple.svg" class="smaller-icon" alt="">
                </div>
            </div>
            <div class="bottom-header">
                <div class="buger-button" id="bugerButton">
                    <span class="line">&nbsp;</span>
                    <span class="line">&nbsp;</span>
                    <span class="line">&nbsp;</span>
                </div>
                <img class="mushroom" src="assets/menu.svg" alt="">
                <div class="sidemenu" id="sidemenu">
                    <div class="categories">
                        <img src="assets/x.svg" class="close" alt="">
                        <div class="category">
                            <div class="category-title-wrapper">
                                <h1 class="category-title">הופעות</h1>
                                <img src="assets/down_arrow.svg" class="down-arrow" alt="">
                            </div>
                            <?php build_mobile_sub_categories(array('Sweet child', 'Sweet child'), 0) ?>
                        </div>
                        <div class="category">
                            <div class="category-title-wrapper">
                                <h1 class="category-title">הופעות</h1>
                                <img src="assets/down_arrow.svg" class="down-arrow" alt="">
                            </div>
                            <?php build_mobile_sub_categories(array('Sweet child', 'Sweet child'), 1) ?>
                        </div>
                        <div class="category">
                            <div class="category-title-wrapper">
                                <h1 class="category-title">הופעות</h1>
                                <img src="assets/down_arrow.svg" class="down-arrow" alt="">
                            </div>
                            <?php build_mobile_sub_categories(array('Sweet child', 'Sweet child'), 2) ?>
                        </div>
                        <div class="category">
                            <div class="category-title-wrapper">
                                <h1 class="category-title">הופעות</h1>
                                <img src="assets/down_arrow.svg" class="down-arrow" alt="">
                            </div>
                            <?php build_mobile_sub_categories(array('Sweet child', 'Sweet child'), 3) ?>
                        </div>
                        <div class="category">
                            <div class="category-title-wrapper">
                                <h1 class="category-title">הופעות</h1>
                                <img src="assets/down_arrow.svg" class="down-arrow" alt="">
                            </div>
                            <?php build_mobile_sub_categories(array('Sweet child', 'Sweet child'), 4) ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="main-banner-wrapper">
        <img src="assets/placeholder-image.jpg" class="main-banner" alt="">
        <h1 class="main-banner-title">אריאנה גרנדה בוינה</h1>
        <p class="main-banner-description">שירות טיקטים 360 – הדרך שלכם להבטיח את החבילה המושלמת!</p>
        <div class="form-header" id="searchForm">
            <div class="submit-container mobile">
                <input type="submit" class="submit" id="extend-form" value="">
                <img src="assets/search.svg" class="submit-icon " alt="">
            </div>
            <div class="icon-input">
                <input type="text" name="" class="text-input" placeholder="אמן/קבוצה">
                <img src="assets/people.svg" class="icon" alt="">
            </div>
            <div class="icon-input">
                <input type="text" name="" class="text-input" placeholder="עיר/מדינה">
                <img src="assets/location.svg" class="icon" alt="">
            </div>
            <!-- https://flatpickr.js.org/examples/#range-calendar -->
            <div class=" icon-input">
                <div id="date-input" class="date-picker">תאריך</div>
                <img src="assets/calendar.svg" class="icon" alt="">
            </div>
            <div class=" icon-input">
                <select name="" class="text-input">
                    <option value="" disabled selected>סוג האירוע </option>
                    <option value="">Option 1</option>
                    <option value="">Option 1</option>
                </select>
                <img src="assets/type.svg" class="icon" alt="">
            </div>
            <!-- 2 submit down here 1 for desktop and other for mobile -->
            <div class="submit-container desktop">
                <input type="submit" class="submit" value="">
                <img src="assets/search.svg" class="submit-icon" alt="">
            </div>
            <div class="submit-container mobile" id="close-form">
                <input type="submit" class="submit" value="">
                <img src="assets/search.svg" class="submit-icon" alt="">
            </div>
        </div>
    </div>